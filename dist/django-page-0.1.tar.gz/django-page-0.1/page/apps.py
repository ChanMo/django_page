#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class PageConfig(AppConfig):
    name = u'page'
    verbose_name = u'文章'
